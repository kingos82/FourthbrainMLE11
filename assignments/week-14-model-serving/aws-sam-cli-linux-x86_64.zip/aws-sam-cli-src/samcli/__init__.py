"""
SAM CLI version
"""

__version__ = "1.76.0"
